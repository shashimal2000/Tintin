let handler = async (m, { conn, args, text }) => {
  if (!text) return m.reply('👉 පාවිච්චි කරන්න: .xnxx <නම>');

  try {
    let res = await fetch(`https://guru-scrapper.cyclic.app/api/xnxxsearch?query=${encodeURIComponent(text)}`);
    let json = await res.json();

    if (!json.data || json.data.length === 0) return m.reply('😢 කිසිම ප්‍රතිඵලයක් හමු නොවුණා.');

    let result = json.data[0];

    let res2 = await fetch(`https://guru-scrapper.cyclic.app/api/xnxxdl?url=${encodeURIComponent(result.link)}`);
    let json2 = await res2.json();

    if (!json2.data || !json2.data.high) return m.reply('😢 video එක download කරන්න බැරිවුණා.');

    await conn.sendFile(m.chat, json2.data.high, 'xnxx.mp4', `🍌 *${result.title}*`, m);
  } catch (e) {
    console.error(e);
    m.reply('🥲 දෝෂයක් සිදුවුණා. ටිකක් ඉන්න.');
  }
};

handler.command = ['xnxx'];
handler.tags = ['nsfw'];
handler.help = ['xnxx <query>'];
handler.group = true;

export default handler;
